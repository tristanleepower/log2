DUT1 System Hang
DUT2 System Hang
DUT3 System Hang
DUT4 System Hang
DUT5 Shutdown
DUT6 Alive
DUT7 enter COS
DUT8 SLB log forever

